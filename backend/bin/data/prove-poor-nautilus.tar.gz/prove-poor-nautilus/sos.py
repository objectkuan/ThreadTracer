#!/usr/bin/python

import re
import sys

fin = sys.argv[1]

state = 0

ENTER_FUTEX = 0
EXIT_FUTEX  = 1
ENTER_POLL  = 2
EXIT_POLL   = 3
WAKEUP      = 4

thread_id = 0
futex_id = 0
poll_id = 0
from_time = 0
to_time = 0
task_ret = 0

dep_thread_id = 0
dep_time = 0

thread_ids = [29191, 29196, 29197, 29198, 29199, 29200, 29201, 29202, 29203, 29205, 29206, 29306, 29411, 29498, 29539, 29580]

def walk_state(op):
	global state
	global thread_id, futex_id, poll_id, from_time, to_time, task_ret, dep_thread_id, dep_time
	global ENTER_FUTEX, EXIT_FUTEX, ENTER_POLL, EXIT_POLL, WAKEUP
	if state == 0:
		if op == ENTER_FUTEX:
			state = 1
		elif op == ENTER_POLL:
			state = 4
		else:
			state = 0
	elif state == 1:
		if op == WAKEUP:
			state = 2
		elif op == EXIT_FUTEX:
			# print "{} ({}, {}, {:12}) <>".format(thread_id, from_time, to_time, int(to_time) - int(from_time))
			state = 0
		else:
			state = 0
	elif state == 2:
		if op == EXIT_FUTEX:
			state = 20
			walk_state(-1)
		else:
			state = 0
	elif state == 4:
		if op == WAKEUP:
			state = 5
		elif op == EXIT_POLL:
			# print "{} ({}, {}, {:12}) <>".format(thread_id, from_time, to_time, int(to_time) - int(from_time))
			state = 0
		else:
			state = 0
	elif state == 5:
		if op == EXIT_POLL:
			state = 21
			walk_state(-1)
		else:
			state = 0
	elif state == 20:
		sleep_time = int(to_time) - int(from_time)
		if int(thread_id) in thread_ids and int(dep_thread_id) in thread_ids and sleep_time > 500000:
			print "{} ({}, {}, {:12}) <= {} ({})".format(thread_id, from_time, to_time, sleep_time, dep_thread_id, dep_time)
		state = 0
	elif state == 21:
		sleep_time = int(to_time) - int(from_time)
		if int(thread_id) in thread_ids and int(dep_thread_id) in thread_ids and sleep_time > 500000:
			print "{} ({}, {}, {:12}) <= {} ({})".format(thread_id, from_time, to_time, sleep_time, dep_thread_id, dep_time)
		state = 0

for line in open(fin):
	# Thread 29580 (24 pool)
	prog = re.compile(r'\tThread\s(\d+)\s\((\d+)\s(.*)\)')
	m = prog.match(line)
	if m:
		pid = m.group(1)
		amount = m.group(2)
		name = m.group(3)
		
		print line.strip()
		state = 0
		walk_state(-1)
		continue


	# 593914145898 CREATE_WAKEUP 29197 29580
	prog = re.compile(r'\t\t(\d+)\sCREATE_WAKEUP\s(\d+)\s(\d+)')
	m = prog.match(line)
	if m:
		time = m.group(1)
		ppid = m.group(2)
		cpid = m.group(3)

		walk_state(-1)
		continue

	# 593914145913 ENTER_FUTEX 29580 12238064
	prog = re.compile(r'\t\t(\d+)\sENTER_FUTEX\s(\d+)\s(\d+)')
	m = prog.match(line)
	if m:
		time = m.group(1)
		pid = m.group(2)
		fid = m.group(3)

		thread_id = pid
		futex_id = fid
		from_time  = time
		walk_state(ENTER_FUTEX)
		continue

	# 593914145917 EXIT_FUTEX 29580 1 SLT: 4
	prog = re.compile(r'\t\t(\d+)\sEXIT_FUTEX\s(\d+)\s(-*\d+)\sSLT:\s(\d+)')
	m = prog.match(line)
	if m:
		time = m.group(1)
		pid = m.group(2)
		retv = m.group(3)
		slt = m.group(4)

		to_time = time
		task_ret = retv
		walk_state(EXIT_FUTEX)
		continue

	# 593869601568 ENTER_POLL 29197 140733779528304
	prog = re.compile(r'\t\t(\d+)\sENTER_POLL\s(\d+)\s(\d+)')
	m = prog.match(line)
	if m:
		time = m.group(1)
		pid = m.group(2)
		poid = m.group(3)

		thread_id = pid
		poll_id = pid
		from_time = time
		walk_state(ENTER_POLL)
		continue

	# 593869601575 EXIT_POLL 29197 SLT: 7
	prog = re.compile(r'\t\t(\d+)\sEXIT_POLL\s(\d+)\sSLT:\s(\d+)')
	m = prog.match(line)
	if m:
		time = m.group(1)
		pid = m.group(2)
		slt = m.group(3)

		to_time = time
		task_ret = 0
		walk_state(EXIT_POLL)
		continue

	# 593869601664 WAKEUP 1487 ==> 29197
	prog = re.compile(r'\t\t(\d+)\sWAKEUP\s(\d+)\s==>\s(\d+)')
	m = prog.match(line)
	if m:
		time = m.group(1)
		fpid = m.group(2)
		tpid = m.group(3)

		dep_thread_id = fpid
		dep_time = time
		walk_state(WAKEUP)
		continue

